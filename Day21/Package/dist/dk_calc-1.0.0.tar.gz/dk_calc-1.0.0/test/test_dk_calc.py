from dk_calc.dk_calc import addition

def test_addition():
    assert addition(5, 5) == 10